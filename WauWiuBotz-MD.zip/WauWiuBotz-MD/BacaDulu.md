SC BY NOVI-MD
IG:Novi_Noviyyy
Wa : wa.me/6282114367104
YT : NOVI_NOVY

•NOVI-BOTZ

JANGAN HAPUS KONTOL
JADI MALES EDIT KONTOL UDH UPLOAD FREE NO ENC ANJ 

JANGAN DIJUAL SCNYA KNTL😡

command termux
pkg update && pkg upgrade
pkg install bash
pkg install nodejs
pkg install libwebp
pkg install imagemagick
termux-setup-storage
cd /sdcard
cd file lu
npm start

<THANK To>
https://github.com/NOVI-MD/RAIDEN'
https://github.com/LeliaBOTZ/LEYLIA'
https://github.com/FARRA_BTZ/FARY'
https://github.com/TASYA-MD/TAS-BOTZ-MD'
https://github.com/NAIELA-BOT/ELLA1'
https://github.com/LINA-MD/LINAA-CHAN'
https://github.com/CIPA-MULTI/CIPACANTI'
https://github.com/DINAA7/DINO_BOTZ'
https://github.com/VIKAMD/PIKA_CHN'