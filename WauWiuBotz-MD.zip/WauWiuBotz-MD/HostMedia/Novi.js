{
	"name": "Novi Bot Multi Device "
}